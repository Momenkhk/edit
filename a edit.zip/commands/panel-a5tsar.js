
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'panel-a5tsar',
    adminOnly: true,
    async execute(message) {
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('open_shortcut_create_modal')
                .setLabel('إضافة اختصار')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('open_shortcut_delete_modal')
                .setLabel('حذف اختصار')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('show_shortcuts_list')
                .setLabel('عرض الاختصارات')
                .setStyle(ButtonStyle.Primary)
        );

        await message.channel.send({
            content: [
                '## لوحة إدارة الاختصارات',
                '• زر **إضافة اختصار**: إضافة اختصار جديد مع الرسالة وخيار حذف رسالة العضو.',
                '• زر **حذف اختصار**: حذف أي اختصار موجود.',
                '• زر **عرض الاختصارات**: مشاهدة كل الاختصارات الحالية.'
            ].join('\n'),
            components: [row],
        });

        await message.delete().catch(() => {});
    },
};
