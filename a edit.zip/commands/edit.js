const { SlashCommandBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
    name: 'edit',
    aliases: ['تعديل'],
    description: 'تعديل رسالة موجودة عبر الآيدي (للإدارة فقط).',
    usage: '$edit <messageId> <newMessage>',
    data: new SlashCommandBuilder()
        .setName('edit')
        .setDescription('تعديل رسالة موجودة في نفس الروم عبر الآيدي (للإدارة فقط)')
        .addStringOption(option =>
            option
                .setName('message_id')
                .setDescription('آيدي الرسالة المراد تعديلها')
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName('new_message')
                .setDescription('النص الجديد للرسالة')
                .setRequired(true)
        ),

    async execute(ctx, args = []) {
        const isInteraction = typeof ctx.isChatInputCommand === 'function' && ctx.isChatInputCommand();

        if (isInteraction) {
            if (!ctx.member.roles.cache.has(config.adminRole)) {
                return ctx.reply({
                    content: '**<:No:1490034325280788541> | ليس لديك صلاحية استخدام هذا الأمر.**',
                    ephemeral: true,
                });
            }

            const messageId = ctx.options.getString('message_id', true).trim();
            const newContent = ctx.options.getString('new_message', true).trim();

            if (!/^\d{17,20}$/.test(messageId)) {
                return ctx.reply({
                    content: '**<a:MV_animated_warn:1490377900535582872> | آيدي الرسالة غير صحيح.**',
                    ephemeral: true,
                });
            }

            try {
                const targetMessage = await ctx.channel.messages.fetch(messageId);
                await targetMessage.edit({ content: newContent });

                return ctx.reply({
                    content: `**<a:yes:1490033686144352600> | تم تعديل الرسالة بنجاح.**\n${targetMessage.url}`,
                    ephemeral: true,
                });
            } catch {
                return ctx.reply({
                    content: '**<:No:1490034325280788541> | تعذر العثور على الرسالة أو تعديلها.**',
                    ephemeral: true,
                });
            }
        }

        const message = ctx;
        if (!message.member.roles.cache.has(config.adminRole)) return;

        const repliedMessageId = message.reference?.messageId;

        // حالة 1: أمر على رسالة عبر الريلاي -> $edit <النص الجديد>
        if (repliedMessageId) {
            const newContentFromReply = args.join(' ').trim();
            if (!newContentFromReply) return;

            try {
                const targetMessage = await message.channel.messages.fetch(repliedMessageId);
                await targetMessage.edit({ content: newContentFromReply });
                await message.delete().catch(() => {});
                return;
            } catch {
                return;
            }
        }

        // حالة 2: الطريقة القديمة -> $edit <messageId> <newMessage>
        const messageId = (args.shift() || '').trim();
        const newContent = args.join(' ').trim();

        if (!messageId || !newContent) return;

        if (!/^\d{17,20}$/.test(messageId)) return;

        try {
            const targetMessage = await message.channel.messages.fetch(messageId);
            await targetMessage.edit({ content: newContent });
            await message.delete().catch(() => {});
            return;
        } catch {
            return;
        }
    },
};
