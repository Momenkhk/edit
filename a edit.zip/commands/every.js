const config = require('../config.json');

module.exports = {
    name: 'every',
    description: 'منشن @everyone ثم حذف الرسالتين بعد ثانية (للإدارة فقط).',
    usage: '$every',

    async execute(message) {
        if (!message.member.permissions.has('Administrator')) return;
        try {
            const sent = await message.channel.send({
                content: '@everyone',
                allowedMentions: { parse: ['everyone'] },
            });

            setTimeout(() => {
                sent.delete().catch(() => {});
                message.delete().catch(() => {});
            }, 10);
        } catch (err) {
            console.error('every command error:', err);
        }
    },
};
