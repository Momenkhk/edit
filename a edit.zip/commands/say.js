module.exports = {
    name: 'say',
    description: 'يجعل البوت يكرر كلامك (للإدارة فقط)',
    async execute(message, args) {
        // 1. استيراد الإعدادات للتحقق من الرتبة
        const config = require('../config.json');

        // 2. التحقق من أن المستخدم لديه رتبة الإدارة المحددة في config.json
        if (!message.member.roles.cache.has(config.adminRole)) {
            return message.reply('**عذراً، هذا الأمر مخصص للإدارة فقط!**')
                .then(msg => {
                    setTimeout(() => msg.delete(), 5000); // حذف رد البوت بعد 5 ثواني
                });
        }

        // 3. التحقق من وجود نص بعد الأمر
        const text = args.join(' ');
        if (!text) {
            return message.reply('**يرجى كتابة الرسالة التي تريدني أن أقولها!**')
                .then(msg => {
                    setTimeout(() => msg.delete(), 5000);
                });
        }

        // 4. حذف رسالة العضو الأصلية (التي تحتوي على الأمر)
        await message.delete().catch(err => console.log("تعذر حذف الرسالة: ", err));

        // 5. إرسال النص بواسطة البوت
        await message.channel.send({ content: text });
    }
};
