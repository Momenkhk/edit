module.exports = {
    name: 'point',
    aliases: ['points', 'نقاطي'],
    async execute(message, args) {
        // تحديد الشخص الممنشن أو صاحب الرسالة
        const target = message.mentions.users.first() || message.author;

        // سحب النقاط من المتغير العالمي المعرف في index.js
        // استخدمنا || 0 عشان لو الشخص ما عنده سجل نقاط يطلع له 0 بدل ما يوقف الكود
        const points = global.usersPoints && global.usersPoints[target.id] ? global.usersPoints[target.id] : 0;

        try {
            const responseText = target.id === message.author.id 
                ? `** your account points is \`${points}\`. <a:coins:1490032989105553459> **`
                : `** <@${target.id}> account points is \`${points}\`. <a:coins:1490032989105553459> **`;

            await message.reply({ 
                content: responseText,
                allowedMentions: { repliedUser: false, users: [target.id] } 
            });
        } catch (error) {
            console.error("Error in points command:", error);
        }
    }
};
