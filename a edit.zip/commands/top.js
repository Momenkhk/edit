const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
    name: 'top',
    aliases: ['التوب'],
    async execute(message, args, client) {
        // التحقق من الرتبة: الأمر مخصص فقط لرتبة الإدارة المحددة في config.json
        if (!message.member.roles.cache.has(config.adminRole)) {
            return; // تجاهل الأمر تماماً إذا لم يكن المستخدم استاف
        }

        // دالة لجلب البيانات وترتيبها
        const getLeaderboardData = () => {
            // تحويل كائن النقاط من المتغير العالمي إلى مصفوفة قابلة للترتيب
            const sorted = Object.entries(global.usersPoints || {})
                .map(([id, points]) => ({ id, points }))
                .sort((a, b) => b.points - a.points) // ترتيب تنازلي
                .slice(0, 10); // أخذ أول 10 فقط

            if (sorted.length === 0) return "لا توجد بيانات نقاط حالياً.";

            return sorted.map((user, index) => {
                let position = "";
                if (index === 0) position = "<:Top1:1491944740856270879>";
                else if (index === 1) position = "<:Top2:1491944751652409355>";
                else if (index === 2) position = "<:Top3:1491944762608058388>";
                else position = `**#${index + 1}**`;

                return `${position} <@${user.id}> — \`${user.points}\` عملة`;
            }).join('\n');
        };

        // إنشاء الإمبد الأول لإرساله
        const embed = new EmbedBuilder()
            .setTitle('توب اعلي ناس معهم عملات ')
            .setDescription(getLeaderboardData())
            .setThumbnail(message.guild.iconURL()) // شعار السيرفر
            .setFooter({ text: 'يتم التحديث تلقائياً كل دقيقة' })
            .setTimestamp();

        // إرسال الرسالة
        const topMessage = await message.reply({ embeds: [embed] });

        // التحديث التلقائي كل دقيقة (60000 مللي ثانية)
        const interval = setInterval(async () => {
            try {
                // جلب الرسالة للتأكد من وجودها (إذا تم حذفها يتوقف المؤقت)
                const checkMsg = await message.channel.messages.fetch(topMessage.id).catch(() => null);
                if (!checkMsg) return clearInterval(interval);

                // تحديث الإمبد بالبيانات الجديدة والترتيب الجديد
                const updatedEmbed = EmbedBuilder.from(embed)
                    .setDescription(getLeaderboardData())
                    .setTimestamp();

                await topMessage.edit({ embeds: [updatedEmbed] });
            } catch (e) {
                console.error("خطأ أثناء تحديث التوب:", e);
                clearInterval(interval);
            }
        }, 60000); 
    }
};
