const { SlashCommandBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
    // تعريف السلاش كوماند
    data: new SlashCommandBuilder()
        .setName('close')
        .setDescription('غلق استقبال الطلبات في المتجر'),

    async execute(interaction) {
        // التحقق من الرتبة المحددة في الكونفج
        if (!interaction.member.roles.cache.has(config.adminRole)) {
            return interaction.reply({ 
                content: '<:No:1490034325280788541> **ليس لديك صلاحية لاستخدام هذا الأمر!**', 
                ephemeral: true 
            });
        }

        // تغيير الحالة في القاعدة العامة
        global.isStoreOpen = false;
        global.saveDatabase();

        // الرد على المسؤول
        await interaction.reply({ 
            content: '**تم غلق استقبال الطلبات بنجاح <a:yes:1490033686144352600>**' 
        });
    }
};
