const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const config = require('../config.json');

module.exports = {
    name: 'dn',
    async execute(message, args) {
        // التحقق من صلاحية الإدارة من الكونفج
        if (!message.member.roles.cache.has(config.adminRole)) return;

        const member = message.mentions.members.first();
        if (!member) return message.reply('**يرجى منشن الشخص المراد إنهاء طلبه!**');

        const roleID = "1489778864895955005";

        try {
            // 1. إعطاء الرتبة
            await member.roles.add(roleID).catch(() => console.log("لم أتمكن من إعطاء الرتبة، تأكد من ترتيب رتبة البوت"));

            // 2. إضافة نقطة في الداتا
            let database = JSON.parse(fs.readFileSync('./database.json', 'utf8'));
            if (!database.usersPoints) database.usersPoints = {};
            
            if (!database.usersPoints[member.id]) {
                database.usersPoints[member.id] = 1;
            } else {
                database.usersPoints[member.id] += 1;
            }
            
            fs.writeFileSync('./database.json', JSON.stringify(database, null, 2));

            // 3. إرسال رسالة الخاص
            const dmMessage = `**شكرا لاختيارك FR3ON $TORE**\n\n> **نتمنى لك ان تكون الخدمة قد اعجبتك.**\n> **لا تنسا أن تضع رأيك هنا: <#1489778616605737140> **\n\n**تم منحك رتبه : <@&${roleID}> **`;
            
            await member.send({ content: dmMessage }).catch(() => {
                message.channel.send(`⚠️ تعذر إرسال رسالة للخاص لـ ${member} لأن حسابه مغلق، لكن تم إعطاؤه الرتبة والنقطة.`);
            });

            message.reply(`**<a:yes:1490033686144352600> تم إنهاء الطلب بنجاح لـ ${member}\nتم منحه الرتبة وإضافة نقطة لرصيده.**`);

        } catch (error) {
            console.error(error);
            message.reply('حدث خطأ أثناء تنفيذ الأمر.');
        }
    }
};
