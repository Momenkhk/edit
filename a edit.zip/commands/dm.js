const { PermissionsBitField } = require('discord.js');
const config = require('../config.json'); // استدعاء ملف الكونفج

module.exports = {
  name: 'dm',
  aliases: ['ارسال', 'ارسل', 'أرسال', 'أرسل'],
  description: 'يرسل رسالة خاصة لشخص محدد.',
  usage: '$dm @user/id message',

  async execute(message, args) {
    const { guild, author, member, content: msgContent, attachments } = message;

    // دالة الرد المؤقت
    async function sendTempReply(content) {
      const reply = await message.reply({
        content,
        allowedMentions: { repliedUser: false }
      });
      setTimeout(() => {
        reply.delete().catch(() => {});
      }, 3000);
    }

    try {
      // التحقق من الصلاحية: (الرتبة المحددة في الكونفج فقط)
      const hasRole = member.roles.cache.has(config.adminRole);

      if (!hasRole) return; // إذا ما عنده الرتبة المحددة بالكونفج يسحب عليه

      if (!args[0]) {
        return sendTempReply('**<a:MV_animated_warn:1490377900535582872> | يجب تحديد الشخص (منشن أو آيدي).**');
      }

      // تنظيف الآيدي من أي رموز منشن
      let userId = args[0].replace(/[<@!>]/g, '');
      
      if (!/^\d{17,20}$/.test(userId)) {
        return sendTempReply('**<a:MV_animated_warn:1490377900535582872> | آيدي الشخص غير صحيح.**');
      }

      let target;
      try {
        target = await guild.members.fetch(userId);
      } catch {
        return sendTempReply('**<:No:1490034325280788541> | لا يمكن العثور على هذا الشخص في السيرفر.**');
      }

      // منع إرسال رسائل للبوتات أو لنفسك
      if (target.user.bot || target.id === author.id) {
        return message.reply({ content: '**<:No:1490034325280788541> | لا يمكنك إرسال رسالة لهذا الشخص.**', allowedMentions: { repliedUser: false }});
      }

      // استخراج نص الرسالة
      const firstArg = args[0];
      const indexAfterMention = msgContent.indexOf(firstArg) + firstArg.length;
      const messageText = msgContent.slice(indexAfterMention).trim();

      if (!messageText && attachments.size === 0) {
        return sendTempReply('**<a:MV_animated_warn:1490377900535582872> | يجب كتابة رسالة أو إرفاق ملف.**');
      }

      try {
        // إرسال الرسالة الخاصة
        await target.send({
          content: messageText || null,
          files: attachments.map(att => att.url)
        });

        // تأكيد النجاح
        await message.reply({
          content: `**<a:yes:1490033686144352600> | تم إرسال الرسالة إلى <@${target.user.id}> بنجاح.**`,
          allowedMentions: { users: [] }
        });

      } catch (err) {
        message.reply({ 
          content: '**<:No:1490034325280788541> | فشل في الإرسال (قد يكون المستخدم أغلق الرسائل الخاصة لديه).**', 
          allowedMentions: { repliedUser: false }
        });
      }

    } catch (err) {
      console.error("DM Command Error:", err);
    }
  }
};
