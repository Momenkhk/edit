const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config.json');
const fs = require('fs');

// آيدي روم الدلائل المخصص
const PROOF_CHANNEL_ID = "1489736295591837746";

function getNextProofNumber() {
    let data = { proofCount: 0 };
    if (fs.existsSync('./database.json')) {
        data = JSON.parse(fs.readFileSync('./database.json', 'utf8'));
    }
    data.proofCount = (data.proofCount || 0) + 1;
    fs.writeFileSync('./database.json', JSON.stringify(data, null, 4));
    return data.proofCount;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('proof')
        .setDescription('إرسال دليل ثقة جديد')
        .addUserOption(option => option.setName('client').setDescription('العميل').setRequired(true))
        .addUserOption(option => option.setName('owner').setDescription('الأونر المسؤول').setRequired(true))
        .addStringOption(option => option.setName('info').setDescription('المعلومات (مثل: مسوي ايميل)').setRequired(true))
        .addAttachmentOption(option => option.setName('image').setDescription('صورة الدليل').setRequired(true)),

    async execute(interaction) {
        // التحقق من الرتبة من الكونفج
        if (!interaction.member.roles.cache.has(config.adminRole)) {
            return interaction.reply({ 
                content: '<:No:1490034325280788541> هذا الأمر مخصص للإدارة فقط.', 
                ephemeral: true 
            });
        }

        const client = interaction.options.getUser('client');
        const owner = interaction.options.getUser('owner');
        const info = interaction.options.getString('info');
        const image = interaction.options.getAttachment('image');
        
        const proofNum = getNextProofNumber();
        const line = '<a:awhiteline:1490035298845982881>'.repeat(15); 

        const proofEmbed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setTitle(`دليل ثقة جديد رقم #${proofNum}`)
            .setDescription(`**شكرا لاستخدامك خدماتنا <:hug:1489767585326039071>**\n\n${line}\n\n**التفاصيل :**\n<:Client:1490035736718737619> **العميل:** <@${client.id}>\n<a:VipClient:1490035581223178331> **الأونر:** <@${owner.id}>\n<:folder:1459280214390472992> **المعلومات:** ${info}`)
            .setImage(image.url)
            .setFooter({ text: `Paris Town Store`, iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        // جلب الروم المخصص للإرسال
        const targetChannel = interaction.guild.channels.cache.get(PROOF_CHANNEL_ID);

        if (!targetChannel) {
            return interaction.reply({ 
                content: '<:No:1490034325280788541> تعذر العثور على روم الدلائل المخصص. تأكد من الآيدي.', 
                ephemeral: true 
            });
        }

        // إرسال الإمبد في الروم المحدد
        await targetChannel.send({ embeds: [proofEmbed] });

        // الرد على المستخدم لتأكيد الإرسال
        await interaction.reply({ 
            content: `<a:yes:1490033686144352600> تم إرسال دليل الثقة بنجاح في <#${PROOF_CHANNEL_ID}>`, 
            ephemeral: true 
        });
    }
};
