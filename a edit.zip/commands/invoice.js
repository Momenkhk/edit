const { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const config = require('../config.json');
const path = require('path');

const BACKGROUND_PATH = path.join(__dirname, '../invoice_bg.png');
const LOG_CHANNEL_ID = "1490103783479443476";

module.exports = {
    data: new SlashCommandBuilder()
        .setName('فاتوره')
        .setDescription('انشاء فاتورة شراء ')
        .addStringOption(option => option.setName('description').setDescription('وصف الخدمة').setRequired(true))
        .addNumberOption(option => option.setName('rate').setDescription('السعر الفردي (Rate)').setRequired(true))
        .addIntegerOption(option => option.setName('qty').setDescription('الكمية (QTY)').setRequired(true))
        .addUserOption(option => option.setName('client').setDescription('العميل الموجه له الفاتورة').setRequired(true)),

    async execute(interaction) {
        if (!interaction.member.roles.cache.has(config.adminRole)) {
            return interaction.reply({ content: '❌ الرتبة غير صالحة.', ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            const desc = interaction.options.getString('description');
            const rate = interaction.options.getNumber('rate');
            const qty = interaction.options.getInteger('qty');
            const client = interaction.options.getUser('client');
            const amount = (rate * qty).toFixed(2);

            const now = new Date();
            const dateStr = now.toLocaleDateString('en-GB', { timeZone: 'Africa/Cairo' });
            const timeStr = now.toLocaleTimeString('en-US', { timeZone: 'Africa/Cairo', hour: '2-digit', minute: '2-digit', hour12: true });

            const background = await loadImage(BACKGROUND_PATH);
            const canvas = createCanvas(background.width, background.height); 
            const ctx = canvas.getContext('2d');
            ctx.drawImage(background, 0, 0);

            ctx.fillStyle = '#ffffff';
            
            // 1. التاريخ والوقت (أقصى اليمين - خط صغير)
            ctx.font = '20px sans-serif'; 
            ctx.fillText(dateStr, 1055, 175); // التاريخ تحت التاريخ والوقت
            ctx.fillText(timeStr, 1067, 195); // الوقت تحت التاريخ

            // 2. العميل (Bill To)
            ctx.font = 'bold 22px sans-serif';
            ctx.fillText(client.username, 185, 328); 

            // 3. الجدول (نفس توزيع صورة 3shmar)
            ctx.font = '20px sans-serif';
            ctx.fillText(desc, 169, 464);           // تحت Description
            ctx.fillText(`${rate} $`, 474, 464);    // تحت Rate
            ctx.fillText(qty.toString(), 645, 464);  // تحت QTY
            ctx.fillText(`${amount} $`, 809, 464);  // تحت Amount

            // 4. الإجمالي (Total) - محاذاة مع خانة Rate مثل الصورة
            ctx.font = 'bold 20px sans-serif';
            ctx.fillText(`${amount} $`, 470, 574); 

            const attachment = new AttachmentBuilder(await canvas.encode('png'), { name: 'invoice.png' });
            
            // إرسال للعميل
            try {
                await client.send({ content: `**Hi <@${client.id}>,**\n**تم إصدار فاتورة جديدة لك من Paris Town ♡**`, files: [attachment] });
            } catch (e) { console.log("DM Closed."); }

            // إرسال للوج
            const logChannel = interaction.guild.channels.cache.get(LOG_CHANNEL_ID);
            if (logChannel) {
                await logChannel.send({ 
                    content: `**📄 فاتورة جديدة صادرة لـ <@${client.id}> بواسطة <@${interaction.user.id}>**`, 
                    files: [attachment] 
                });
            }

            await interaction.editReply({ content: `✅ تم إنشاء الفاتورة وإرسالها بنجاح.` });

        } catch (error) {
            console.error(error);
            await interaction.editReply('❌ فشل توليد الفاتورة.');
        }
    }
};
