module.exports = {
    name: 'help',
    execute(message) {
        // التحقق من الرتبة إذا كنت تريد جعل الهيلب للإدارة فقط
        // if (!message.member.roles.cache.has(require('../config.json').adminRole)) return;

        const helpMessage = [
            "قائمة أوامر بوت فرعون ستور:",
            "-------------------------------",
            "$order-panel : لإرسال بانل فتح التذاكر",
            "$open : لفتح استقبال الطلبات (تفعيل القائمة)",
            "$close : لغلق استقبال الطلبات (تعطيل القائمة)",
            "$come @mention : لاستدعاء عضو إلى التكت الحالي",
            "$add @mention/ID : لإضافة عضو لمشاهدة التكت",
            "$remove @mention/ID : لإزالة عضو من التكت",
            "$delete : اختصار لحذف التكت (يفضل استخدام زر الإغلاق)",
            "$prove : لإرسال دليل ثقة جديد لروم الدلائل",
            "-------------------------------"
        ];

        message.reply(helpMessage.join('\n'));
    }
};
