const {
    ButtonBuilder,
    ButtonStyle,
    ContainerBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    MessageFlags,
    SectionBuilder,
    SeparatorBuilder,
    TextDisplayBuilder,
} = require('discord.js');
const config = require('../config.json');

module.exports = {
    name: 'credit-panel',
    adminOnly: true,
    async execute(message, args) {
        // التحقق من الرتبة
        if (!message.member.roles.cache.has(config.adminRole)) return;

        // ضع رابط الصورة الثابت هنا لكي يرسل تلقائياً
        const fixedImageUrl = "https://h.top4top.io/p_3756bcsrt5.png"; 

        // رسالة Components v2 بنظام الزر التلقائي
        const panelContainer = new ContainerBuilder()
            .setAccentColor(0x2a2857)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(' ')
            )
            .addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(fixedImageUrl)
                )
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            )
            .addSectionComponents(
                new SectionBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(' ')
                    )
                    .setButtonAccessory(
                        new ButtonBuilder()
                            .setCustomId('open_credit_ticket') // هذا المربوط بالسكشن في الـ index
                            .setLabel('Create Ticket')
                            .setEmoji('<a:Probot:1491192922652283001>')
                            .setStyle(ButtonStyle.Secondary)
                    )
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );

        await message.channel.send({
            flags: MessageFlags.IsComponentsV2,
            components: [panelContainer],
        });
        
        // حذف رسالة الأمر لتنظيف الشات
        await message.delete().catch(() => {});
    }
};