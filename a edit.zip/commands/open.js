const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('open')
        .setDescription('فتح استقبال الطلبات في المتجر'),

    async execute(interaction) {
        // التحقق من الرتبة الموجودة في الكوفتج
        if (!interaction.member.roles.cache.has(config.adminRole)) {
            return interaction.reply({ 
                content: '<:No:1490034325280788541> ليس لديك صلاحية استخدام هذا الأمر.', 
                ephemeral: true 
            });
        }

        global.isStoreOpen = true;
        global.saveDatabase();

        await interaction.reply({ 
            content: '**<a:yes:1490033686144352600> تم فتح استقبال الطلبات بنجاح**' 
        });
    }
};
