const config = require('../config.json');

module.exports = {
    name: 'come',
    async execute(message, args) {
        // التحقق من الرتبة من الكونفج
        if (!message.member.roles.cache.has(config.adminRole)) return;

        const member = message.mentions.members.first();
        if (!member) return message.reply('**يرجى منشن الشخص المراد استدعاؤه!**');

        try {
            // 1. إرسال رسالة في القناة (تأكيد الاستدعاء)
            await message.channel.send({ 
                content: `**تم إستدعاء <@${member.id}> بنجاح.**` 
            });

            // 2. إرسال الرسالة في الخاص للشخص المستدعى
            await member.send({ 
                content: `**تم إستدعائك بواسطة : <@${message.author.id}>**\n\n**يرجى التوجه إلى <#${message.channel.id}> بأسرع وقت ممكن**\n\n<@${member.id}>` 
            }).catch(() => {
                // إذا كان الخاص مغلقاً، يرسل تنبيهاً بسيطاً في القناة ويحذفه لاحقاً
                message.channel.send(`⚠️ <@${member.id}>، تعذر إرسال رسالة لخاصك، يرجى الانتباه للاستدعاء هنا.`)
                    .then(m => setTimeout(() => m.delete(), 5000));
            });

            // حذف رسالة الأمر الأصلية للحفاظ على نظافة الروم
            await message.delete().catch(() => {});

        } catch (error) {
            console.error("❌ خطأ في أمر الاستدعاء:", error);
            message.reply('حدث خطأ أثناء تنفيذ أمر الاستدعاء.');
        }
    }
};
