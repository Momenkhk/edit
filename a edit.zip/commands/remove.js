module.exports = {
    name: 'remove',
    async execute(message, args) {
        const member = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
        if (!member) return message.reply('**منشن الشخص أو الأيدي!**');
        await message.channel.permissionOverwrites.edit(member, { ViewChannel: false });
        message.reply(`**تم حذف ${member} من التكت.**`);
    }
};
