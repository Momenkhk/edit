const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.json');

module.exports = {
    name: 'credit-panel',
    async execute(message, args) {
        // التحقق من الرتبة
        if (!message.member.roles.cache.has(config.adminRole)) return;

        // أخذ رابط الصورة من أول كلمة بعد الأمر
        const imageUrl = args[0];
        if (!imageUrl) return message.reply('**يرجى وضع رابط الصورة بعد الأمر!**\n`$credit-panel https://example.com/image.png`');

        const embed = new EmbedBuilder()
            .setImage(imageUrl)

        // الزر المطلوب بإيموجي FluriAvt وكلمة Order
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('open_credit_ticket')
                .setLabel('Order')
                .setEmoji('<a:Probot:1491192922652283001>')
                .setStyle(ButtonStyle.Secondary)
        );

        await message.channel.send({ embeds: [embed], components: [row] });
        
        // حذف رسالة الأدمن اللي كتب فيها الأمر
        await message.delete().catch(() => {});
    }
};
