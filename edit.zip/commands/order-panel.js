const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
    name: 'order-panel',
    async execute(message) {
        // التحقق من الرتبة من الكونفج
        if (!message.member.roles.cache.has(config.adminRole)) return;

        const embed = new EmbedBuilder()
            .setImage('https://i.imgur.com/your-laptop-image.png'); // التصاميم يا عبدووووو

        const menu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_ticket')
                .setPlaceholder('Select ticket type...')
                .addOptions([
                    { label: 'Effect', value: '1', emoji: '<a:effect:1489766309255446589>' },
                    { label: 'Nitro', value: '2', emoji: '<:Nitro:1489766405615386755>' },
                    { label: 'Other', value: '3', emoji: '<a:wait:1459324539233243186>' },
                    { label: 'Refresh', value: 'refresh', emoji: '<a:Refresh:1489766942360211658>' }
                ])
        );

        const btns = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Instructions')
                .setURL(`https://discord.com/channels/${message.guild.id}/${config.instructionsChannel}`)
                .setStyle(ButtonStyle.Link),

            new ButtonBuilder()
                .setLabel('Rules')
                .setURL(`https://discord.com/channels/${message.guild.id}/${config.rulesChannel}`)
                .setStyle(ButtonStyle.Link)
        );

        await message.channel.send({ embeds: [embed], components: [menu, btns] });
        await message.delete().catch(() => {});
    }
};
