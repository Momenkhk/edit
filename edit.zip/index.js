const { 
    Client, GatewayIntentBits, Partials, EmbedBuilder, 
    ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, 
    PermissionsBitField, ActivityType, Events, REST, Routes, Collection
} = require('discord.js');

const fs = require('fs');
const config = require('./config.json');
const transcript = require('discord-html-transcripts');

// --- قاعدة البيانات ---
if (!fs.existsSync('./database.json')) {
    fs.writeFileSync('./database.json', JSON.stringify({ isStoreOpen: true, usersPoints: {} }, null, 4));
}
let database = JSON.parse(fs.readFileSync('./database.json', 'utf8'));

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds, 
        GatewayIntentBits.GuildMessages, 
        GatewayIntentBits.MessageContent, 
        GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel]
});

// الثوابت الأساسية
const PARIS_GUILD_ID = "1458985277933617186";
const PARIS_CATEGORY_ID = "1489718083885989898"; 
const TEAM_ROLE_ID = "1491188933751607326";

client.commands = new Collection();
global.isStoreOpen = database.isStoreOpen;
global.usersPoints = database.usersPoints || {};

global.saveDatabase = () => {
    fs.writeFileSync('./database.json', JSON.stringify({
        isStoreOpen: global.isStoreOpen,
        usersPoints: global.usersPoints
    }, null, 4));
};

// --- تحميل الأوامر ---
const slashCommands = [];
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const cmd = require(`./commands/${file}`);
    const name = cmd.name || (cmd.data ? cmd.data.name : null);
    if (name) {
        client.commands.set(name, cmd);
        if (cmd.data) slashCommands.push(cmd.data.toJSON());
    }
}

client.once('ready', async () => {
    console.log(`✅ Logged in: ${client.user.tag}`);
    const rest = new REST({ version: '10' }).setToken(config.token);
    try {
        await rest.put(Routes.applicationGuildCommands(client.user.id, PARIS_GUILD_ID), { body: slashCommands });
    } catch (e) { console.error(e); }

    client.user.setPresence({
        activities: [{ name: `Paris Town`, type: ActivityType.Watching, url: "https://www.twitch.tv/sad_programmer" }],
        status: 'dnd',
    });
});

// --- نظام الشراء (الرسائل العادية) ---
client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot || !message.guild) return;

    // معالجة كلمة "شراء" في كود الشراء العام
    if (message.channel.parentId === PARIS_CATEGORY_ID && message.content === 'شراء' && !message.channel.name.startsWith('credit-')) {
        const paymentMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_pay_method')
                .setPlaceholder('إختر طريقة الدفع المناسبة لك')
                .addOptions([
                    { label: 'فودافون كاش', value: 'فودافون كاش', emoji: '<:Cash:1489762925450367077>' },
                    { label: 'انستا باي', value: 'انستا باي', emoji: '<:Instapay:1489763191537008791>' },
                    { label: 'تيلدا', value: 'تيلدا', emoji: '<:emoji_28:1489763631108456620>' },
                    { label: 'كربتو', value: 'كربتو', emoji: '<:crypto:1489763878018613368>' },
                    { label: 'آسيا سيل', value: 'آسيا سيل', emoji: '<:Asia:1491197708038443139>' },
                    { label: 'كريديت', value: 'كريديت', emoji: '<:credits:1468640707815149732>' },
                    { label: 'دينار كويتي', value: 'دينار كويتي', emoji: '🇰🇼' },
                    { label: 'دينار أردني', value: 'دينار أردني', emoji: '🇯🇴' },
                    { label: 'ريزر', value: 'ريزر', emoji: '<:rezer:1489764712022544580>' },
                    { label: 'إيتونز ', value: 'إيتونز ', emoji: '<:ITUNES:1489765145373704242>' },
                    { label: 'زين كــاش العراق', value: 'زين كــاش العراق', emoji: '<:Zaincash:1489765549033525290>' },
                    { label: 'برق السعودي', value: 'برق السعودي', emoji: '<:barq:1489765792903073842>' },
                    { label: 'تحويل بنكي', value: 'تحويل بنكي', emoji: '🏦' },
                ])
        );
        return message.reply({ 
            content: `**الرجاء اختيار وسيلة الدفع المناسبة لك لإتمام عملية الشراء في Paris Town :**`, 
            components: [paymentMenu] 
        });
    }

    // فحص البريفكس (Prefix)
    if (!message.content.startsWith(config.prefix)) return;
    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const cmdName = args.shift().toLowerCase();
    const cmd = client.commands.get(cmdName) || client.commands.find(c => c.aliases && c.aliases.includes(cmdName));
    
    if (cmd) {
        // --- تعديل الصلاحيات للأوامر العامة ---
        // إذا كان الملف يحتوي على adminOnly: true، يفحص الرتبة. إذا لم يحتوي عليها، يسمح للجميع.
        if (cmd.adminOnly === true) {
            if (!message.member.roles.cache.has(config.adminRole)) return; 
        }
        
        try { 
            await cmd.execute(message, args, client); 
        } catch (e) { 
            console.error(e); 
        }
    }
});

// --- نظام التفاعلات والتكتات ---
client.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isChatInputCommand()) {
        const slash = client.commands.get(interaction.commandName);
        if (slash) await slash.execute(interaction, [], client);
    }

    // 1. عند الضغط على زر فتح تكت الكريديت
    if (interaction.isButton() && interaction.customId === 'open_credit_ticket') {
        if (!global.isStoreOpen) return interaction.reply({ content: `**الخدمة مغلقة مؤقتاً برجاء متابعه مواعيد العمل <#1489725339155431494>. <a:222_za:1490037837830033633> **`, ephemeral: true });

        const checkTicket = interaction.guild.channels.cache.find(c => c.topic === interaction.user.id);
        if (checkTicket) return interaction.reply({ content: `لديك تكت بالفعل: ${checkTicket}`, ephemeral: true });

        const paymentMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('credit_payment_select_before')
                .setPlaceholder('Payment Method')
                .addOptions([
                    { label: 'فودافون كاش', value: 'فودافون كاش', emoji: '<:Cash:1489762925450367077>' },
                    { label: 'انستا باي', value: 'انستا باي', emoji: '<:Instapay:1489763191537008791>' },
                    { label: 'تيلدا', value: 'تيلدا', emoji: '<:emoji_28:1489763631108456620>' },
                    { label: 'كربتو', value: 'كربتو', emoji: '<:crypto:1489763878018613368>' },
                    { label: 'آسيا سيل', value: 'آسيا سيل', emoji: '<:Asia:1491197708038443139>' },
                    { label: 'دينار كويتي', value: 'دينار كويتي', emoji: '🇰🇼' },
                    { label: 'دينار أردني', value: 'دينار أردني', emoji: '🇯🇴' },
                    { label: 'ريزر', value: 'ريزر', emoji: '<:rezer:1489764712022544580>' },
                    { label: 'إيتونز ', value: 'إيتونز ', emoji: '<:ITUNES:1489765145373704242>' },
                    { label: 'زين كــاش العراق', value: 'زين كــاش العراق', emoji: '<:Zaincash:1489765549033525290>' },
                    { label: 'برق السعودي', value: 'برق السعودي', emoji: '<:barq:1489765792903073842>' },
                    { label: 'تحويل بنكي', value: 'تحويل بنكي', emoji: '🏦' },
                ])
        );

        await interaction.reply({ 
            content: `**Please choose your payment method ♡**`, 
            components: [paymentMenu], 
            ephemeral: true 
        });
    }

    // 2. بعد اختيار وسيلة الدفع من القائمة المخفية يتم فتح التكت
    if (interaction.isStringSelectMenu() && interaction.customId === 'credit_payment_select_before') {
        const method = interaction.values[0];
        await interaction.update({ content: `جاري فتح تكت الكريديت بوسيلة: ${method}...`, components: [], ephemeral: true });

        try {
            const ticketChannel = await interaction.guild.channels.create({
                name: `credit-${interaction.user.username}`,
                parent: PARIS_CATEGORY_ID,
                topic: interaction.user.id,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                    { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
                    { id: config.adminRole, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
                ],
            });

            const welcomeEmbed = new EmbedBuilder()
                .setAuthor({ name: `Hello @${interaction.user.username} !`, iconURL: interaction.user.displayAvatarURL() })
                .setDescription(`<:hug:1489767585326039071> **Hello <@${interaction.user.id}> !**\n\n<:emoji_18:1468639510421307615>\n**Your Credit ticket has been successfully opened.**\n\n\n<a:9407pepepopcorn:1490026512882073611>\n**Please wait for the team <@&${TEAM_ROLE_ID}> to assist you.**\n\n**Client:** <@${interaction.user.id}>\n**Creation Time:** <t:${Math.floor(Date.now() / 1000)}:R>\n**Section:** Credit\n**Payment Method:** ${method}\n**Assigned Team:** <@&${TEAM_ROLE_ID}>`)
                .setColor('#2b2d31');

            const closeBtn = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('close_ticket')
                    .setLabel('Close')
                    .setEmoji('<a:close:1489767100900970607>') 
                    .setStyle(ButtonStyle.Danger)
            );

            await ticketChannel.send({ content: `<@${interaction.user.id}> - <@&${TEAM_ROLE_ID}>`, embeds: [welcomeEmbed], components: [closeBtn] });
            await interaction.followUp({ content: `تم فتح تكت الكريديت بنجاح: ${ticketChannel}`, ephemeral: true });
        } catch (e) {
            console.error(e);
        }
    }

    // فتح التكتات العادية (Nitro, Effect, Other)
    if (interaction.isStringSelectMenu() && interaction.customId === 'select_ticket') {
        await interaction.deferReply({ ephemeral: true });
        if (!global.isStoreOpen) return interaction.editReply({ content: `**الخدمة مغلقة مؤقتاً برجاء متابعه مواعيد العمل <#1489725339155431494>. <a:9407pepepopcorn:1490026512882073611> **` });

        const type = interaction.values[0]; 
        if (type === 'refresh') return interaction.editReply({ content: 'تم التحديث.' });

        const sections = {
            'Nitro': { display: 'Nitro <:Nitro:1489766405615386755>' },
            'Effect': { display: 'Effect <a:effect:1489766309255446589>' },
            'Other': { display: 'Other <a:wait:1459324539233243186>' }
        };
        const currentSec = sections[type] || { display: type };

        const checkTicket = interaction.guild.channels.cache.find(c => c.topic === interaction.user.id);
        if (checkTicket) return interaction.editReply({ content: `لديك تكت بالفعل: ${checkTicket}` });

        try {
            const ticketChannel = await interaction.guild.channels.create({
                name: `order-${interaction.user.username}`,
                parent: PARIS_CATEGORY_ID,
                topic: interaction.user.id,
                permissionOverwrites: [
                    { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                    { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
                    { id: config.adminRole, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
                ],
            });

            const welcomeEmbed = new EmbedBuilder()
                .setAuthor({ name: `Hello @${interaction.user.username} !`, iconURL: interaction.user.displayAvatarURL() })
                .setDescription(`<:hug:1489767585326039071> **Hello <@${interaction.user.id}> !**\n\n<:emoji_18:1468639510421307615>\n**Your ${type} ticket has been successfully opened.**\n\n\n<a:9407pepepopcorn:1490026512882073611>\n**Please wait for the team <@&${TEAM_ROLE_ID}> to assist you.**\n\n**Client:** <@${interaction.user.id}>\n**Creation Time:** <t:${Math.floor(Date.now() / 1000)}:R>\n**Section:** ${currentSec.display}\n**Assigned Team:** <@&${TEAM_ROLE_ID}>`)
                .setColor('#2b2d31');

            const closeBtn = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('close_ticket')
                    .setLabel('Close')
                    .setEmoji('<a:close:1489767100900970607>') 
                    .setStyle(ButtonStyle.Danger)
            );

            await ticketChannel.send({ content: `<@${interaction.user.id}> - <@&${TEAM_ROLE_ID}>`, embeds: [welcomeEmbed], components: [closeBtn] });
            await ticketChannel.send({ content: `**Hi - السلام عليكم ورحمة الله وبركاته**\n**Customers _ ♡**\n\n**برجاء كتابه كلمه "شراء" لمعرفة طرق الدفع المتوفره لدينا**\n\n**عند تحويل مبالغ اكثر من $3 انتظر شخص معه رتبه <@&1489784945982570516> فقط !**` });

            await interaction.editReply({ content: `تم فتح التكت بنجاح: ${ticketChannel}` });
        } catch (e) {
            console.error(e);
            await interaction.editReply({ content: '❌ خطأ: تأكد من صلاحيات البوت.' });
        }
    }

    // معالجة اختيار وسيلة الدفع للقائمة العامة (شراء)
    if (interaction.isStringSelectMenu() && interaction.customId === 'select_pay_method') {
        const pay = interaction.values[0];
        await interaction.message.delete().catch(() => {});
        await interaction.channel.send({ content: `**طريقة الدفع المختارة هي: (${pay})**` });
    }

    // نظام الإغلاق
    if (interaction.isButton() && interaction.customId === 'close_ticket') {
        if (!interaction.member.roles.cache.has(config.adminRole)) return interaction.reply({ content: 'للإدارة فقط!', ephemeral: true });
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('confirm_del').setLabel('تأكيد').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('cancel_del').setLabel('إلغاء').setStyle(ButtonStyle.Secondary)
        );
        await interaction.reply({ content: 'تأكيد إغلاق التكت؟', components: [row], ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId === 'confirm_del') {
        await interaction.update({ content: 'جاري الأرشفة والحذف...', components: [] });
        const logCh = client.channels.cache.get(config.logChannel);
        const file = await transcript.createTranscript(interaction.channel, { limit: -1, fileName: `ParisTown-${interaction.channel.name}.html`, poweredBy: false });
        
        const embed = new EmbedBuilder().setTitle('Ticket Closed').addFields({ name: 'User', value: `<@${interaction.channel.topic}>` }, { name: 'Staff', value: `<@${interaction.user.id}>` }).setColor('Red').setTimestamp();

        if (logCh) await logCh.send({ embeds: [embed], files: [file] });
        setTimeout(() => interaction.channel.delete().catch(() => {}), 3000);
    }
    
    if (interaction.isButton() && interaction.customId === 'cancel_del') await interaction.update({ content: 'تم الإلغاء.', components: [], ephemeral: true });
});

client.login(config.token);
